export interface TranslationSet {
  title: string;
  subtitle: string;
  badgePrivacy: string;
  dropzoneTitle: string;
  dropzoneDesc: string;
  selectFiles: string;
  targetSizeLabel: string;
  targetSizeHelp: string;
  enterCustomSize: string;
  unitKb: string;
  unitMb: string;
  presetsTitle: string;
  govtFormsTitle: string;
  govtFormsDesc: string;
  compressNow: string;
  compressing: string;
  compressAll: string;
  downloadAll: string;
  clearAll: string;
  original: string;
  compressed: string;
  saved: string;
  download: string;
  preview: string;
  compare: string;
  pages: string;
  smartMode: string;
  targetSizeMode: string;
  percentageMode: string;
  qualityMode: string;
  formatOption: string;
  originalFormat: string;
  privacyNotice: string;
  noFilesUploaded: string;
  addMoreFiles: string;
  errorProcessing: string;
  customTargetTooltip: string;
  exactTargetReached: string;
}

export const TRANSLATIONS: Record<'hi' | 'en', TranslationSet> = {
  hi: {
    title: 'पीडीएफ और इमेज कंप्रेसर',
    subtitle: 'अपनी मनचाही फाइल साइज (KB या MB) लिखें और तुरंत परफेक्ट क्वालिटी में कंप्रेस करें!',
    badgePrivacy: '100% सुरक्षित और प्राइवेट • कोई फाइल सर्वर पर नहीं जाती',
    dropzoneTitle: 'यहाँ पीडीएफ या फोटो ड्रैग करें या सेलेक्ट करें',
    dropzoneDesc: 'PDF, JPG, PNG, WebP फाइल्स सपोर्टेड (एक साथ कई फाइलें जोड़ सकते हैं)',
    selectFiles: 'फाइल चुनें (Choose Files)',
    targetSizeLabel: 'टारगेट साइज सेट करें (Target File Size)',
    targetSizeHelp: 'यहाँ लिखें आपको कितने KB या MB की फाइल चाहिए',
    enterCustomSize: 'साइज दर्ज करें',
    unitKb: 'KB (केबी)',
    unitMb: 'MB (एमबी)',
    presetsTitle: 'पॉपुलर साइज प्रीसेट्स (Quick Select)',
    govtFormsTitle: 'सरकारी व जॉब फॉर्म्स के लिए साइज:',
    govtFormsDesc: 'SSC, UPSC, आधार, पैन कार्ड, पासपोर्ट व कॉलेज फॉर्म्स के लिए सटीक साइज',
    compressNow: 'कंप्रेस करें',
    compressing: 'कंप्रेस हो रहा है...',
    compressAll: 'सभी फाइलें कंप्रेस करें',
    downloadAll: 'सभी डाउनलोड करें',
    clearAll: 'हटाएं (Clear All)',
    original: 'ओरिजिनल साइज',
    compressed: 'कंप्रेस्ड साइज',
    saved: 'कम हुआ (Saved)',
    download: 'डाउनलोड',
    preview: 'प्रीव्यू देखें',
    compare: 'क्वालिटी तुलना (Compare)',
    pages: 'पेज',
    smartMode: 'स्मार्ट मोड',
    targetSizeMode: 'कस्टम KB / MB मोड',
    percentageMode: 'प्रतिशत (%) मोड',
    qualityMode: 'मैन्युअल क्वालिटी',
    formatOption: 'आउटपुट फॉर्मेट',
    originalFormat: 'ओरिजिनल रखें',
    privacyNotice: 'आपकी फाइल्स आपके ब्राउज़र में ही प्रोसेस होती हैं, कोई भी डेटा कहीं अपलोड नहीं होता।',
    noFilesUploaded: 'कंप्रेस करने के लिए कोई फाइल नहीं चुनी गई है। ऊपर से फाइल अपलोड करें।',
    addMoreFiles: 'और फाइलें जोड़ें',
    errorProcessing: 'फाइल प्रोसेस करने में त्रुटि हुई',
    customTargetTooltip: 'जितना KB या MB आप लिखेंगे, उसी के अंदर फाइल साइज फिट हो जाएगी।',
    exactTargetReached: 'टारगेट साइज के भीतर सफलतापूर्वक कंप्रेस हो गया!',
  },
  en: {
    title: 'PDF & Image Compressor',
    subtitle: 'Type your exact target size in KB or MB to compress with maximum visual quality!',
    badgePrivacy: '100% Private & In-Browser • Files Never Leave Your Device',
    dropzoneTitle: 'Drag & Drop PDF or Images here',
    dropzoneDesc: 'Supports PDF, JPG, PNG, WebP (Single or Batch Upload)',
    selectFiles: 'Browse Files',
    targetSizeLabel: 'Target File Size (KB / MB)',
    targetSizeHelp: 'Specify the exact target size you want the compressed output to fit',
    enterCustomSize: 'Enter size',
    unitKb: 'KB',
    unitMb: 'MB',
    presetsTitle: 'Quick Presets',
    govtFormsTitle: 'Govt & Job Application Form Presets:',
    govtFormsDesc: 'Optimized for UPSC, SSC, Passport, Aadhaar, PAN & College admissions',
    compressNow: 'Compress',
    compressing: 'Compressing...',
    compressAll: 'Compress All Files',
    downloadAll: 'Download All',
    clearAll: 'Clear All',
    original: 'Original Size',
    compressed: 'Compressed Size',
    saved: 'Saved',
    download: 'Download',
    preview: 'Preview',
    compare: 'Compare Quality',
    pages: 'pages',
    smartMode: 'Smart Vector',
    targetSizeMode: 'Exact KB / MB Mode',
    percentageMode: 'Percentage (%) Mode',
    qualityMode: 'Manual Quality',
    formatOption: 'Output Format',
    originalFormat: 'Keep Original',
    privacyNotice: 'All files are processed 100% locally in your browser memory for maximum security and privacy.',
    noFilesUploaded: 'No files selected yet. Drag & drop or browse files above to begin.',
    addMoreFiles: 'Add More Files',
    errorProcessing: 'Error processing file',
    customTargetTooltip: 'The file will be dynamically calibrated to fit within your specified KB/MB budget.',
    exactTargetReached: 'Successfully compressed within target size budget!',
  },
};
