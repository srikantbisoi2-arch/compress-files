import React from 'react';
import { Download, Sparkles, Trash2, Loader2, ArrowRight, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CompressedFileItem } from '../types';
import { TranslationSet } from '../data/translations';
import { formatBytes, calculateSavings, downloadBlob } from '../utils/formatters';

interface BatchSummaryBarProps {
  files: CompressedFileItem[];
  t: TranslationSet;
  lang: 'hi' | 'en';
  isCompressingAll: boolean;
  onCompressAll: () => void;
  onClearAll: () => void;
}

export const BatchSummaryBar: React.FC<BatchSummaryBarProps> = ({
  files,
  t,
  lang,
  isCompressingAll,
  onCompressAll,
  onClearAll,
}) => {
  if (files.length === 0) return null;

  const totalOriginal = files.reduce((acc, f) => acc + f.originalSize, 0);
  const completedFiles = files.filter((f) => f.status === 'completed' && f.compressedSize !== undefined);
  const totalCompressed = completedFiles.reduce((acc, f) => acc + (f.compressedSize || 0), 0);
  
  const allCompleted = completedFiles.length === files.length && files.length > 0;
  const hasCompleted = completedFiles.length > 0;

  const savings =
    hasCompleted && totalCompressed > 0
      ? calculateSavings(
          completedFiles.reduce((acc, f) => acc + f.originalSize, 0),
          totalCompressed
        )
      : null;

  const handleDownloadAll = () => {
    // Trigger confetti celebration!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // safe fallback
    }

    // Sequentially download each completed item with small delay so browser doesn't block
    completedFiles.forEach((item, index) => {
      if (!item.compressedBlob) return;
      setTimeout(() => {
        const ext =
          item.type === 'pdf'
            ? '.pdf'
            : item.compressedBlob!.type.includes('png')
            ? '.png'
            : item.compressedBlob!.type.includes('webp')
            ? '.webp'
            : '.jpg';
        const nameWithoutExt = item.name.replace(/\.[^/.]+$/, '');
        downloadBlob(item.compressedBlob!, `${nameWithoutExt}_compressed${ext}`);
      }, index * 250);
    });
  };

  return (
    <div className="bg-stone-900 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-stone-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
      {/* Left: Overall Stats */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="font-bold text-sm text-stone-200">
            {files.length} {lang === 'hi' ? 'फाइलें जोड़ी गई हैं' : 'Files in Queue'}
          </span>
          <span className="text-xs text-stone-400">
            ({completedFiles.length}/{files.length} {lang === 'hi' ? 'कंप्रेस हो गईं' : 'ready'})
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-stone-400">
            {t.original}:{' '}
            <strong className="text-stone-200 font-mono">{formatBytes(totalOriginal)}</strong>
          </span>

          {hasCompleted && (
            <>
              <ArrowRight className="w-3.5 h-3.5 text-stone-500" />
              <span className="text-emerald-400">
                {t.compressed}:{' '}
                <strong className="font-mono font-bold text-emerald-300">
                  {formatBytes(totalCompressed)}
                </strong>
              </span>

              {savings && (
                <span className="bg-emerald-950/80 text-emerald-300 font-bold px-2 py-0.5 rounded-md border border-emerald-800 text-[11px]">
                  -{savings.percentage.toFixed(1)}% {t.saved} ({formatBytes(savings.savedBytes)})
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Right: Batch Actions */}
      <div className="flex items-center flex-wrap gap-2.5">
        {/* Clear All */}
        <button
          type="button"
          onClick={onClearAll}
          className="px-3 py-2 text-xs font-medium text-stone-400 hover:text-red-400 hover:bg-stone-800 rounded-xl transition-colors flex items-center gap-1.5"
        >
          <Trash2 className="w-4 h-4" />
          <span>{t.clearAll}</span>
        </button>

        {/* Compress All */}
        {!allCompleted && (
          <button
            type="button"
            id="compress-all-btn"
            disabled={isCompressingAll}
            onClick={onCompressAll}
            className="px-5 py-2.5 text-xs sm:text-sm font-bold bg-orange-600 hover:bg-orange-500 active:bg-orange-700 disabled:opacity-50 text-white rounded-xl transition-all shadow-md shadow-orange-600/20 flex items-center gap-2"
          >
            {isCompressingAll ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t.compressing}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{t.compressAll}</span>
              </>
            )}
          </button>
        )}

        {/* Download All */}
        {hasCompleted && (
          <button
            type="button"
            id="download-all-btn"
            onClick={handleDownloadAll}
            className="px-5 py-2.5 text-xs sm:text-sm font-bold bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{t.downloadAll} ({completedFiles.length})</span>
          </button>
        )}
      </div>
    </div>
  );
};
