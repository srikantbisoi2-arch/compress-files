import React from 'react';
import { Award, ArrowUpRight } from 'lucide-react';
import { TargetUnit } from '../types';

interface GovtGuidelineBadgeProps {
  lang: 'hi' | 'en';
  onSelectSize: (size: number, unit: TargetUnit) => void;
}

interface FormRule {
  name: string;
  nameHi: string;
  category: string;
  sizeLimit: string;
  targetSize: number;
  unit: TargetUnit;
}

const FORM_GUIDELINES: FormRule[] = [
  {
    name: 'SSC & UPSC Photo',
    nameHi: 'SSC / UPSC फोटो',
    category: 'Govt Exam',
    sizeLimit: '20 KB - 50 KB',
    targetSize: 45,
    unit: 'KB',
  },
  {
    name: 'Govt Signature Upload',
    nameHi: 'हस्ताक्षर (Signature)',
    category: 'Forms',
    sizeLimit: '10 KB - 20 KB',
    targetSize: 18,
    unit: 'KB',
  },
  {
    name: 'Aadhaar / PAN Card / ID',
    nameHi: 'आधार / पैन कार्ड PDF',
    category: 'ID Proof',
    sizeLimit: 'Max 100 KB - 200 KB',
    targetSize: 100,
    unit: 'KB',
  },
  {
    name: 'College & Job Resume',
    nameHi: 'रिज्यूमे / मार्कशीट',
    category: 'Admission',
    sizeLimit: 'Max 500 KB',
    targetSize: 500,
    unit: 'KB',
  },
  {
    name: 'Passport & Visa Docs',
    nameHi: 'पासपोर्ट / वीजा डॉक्यूमेंट',
    category: 'Travel / Visa',
    sizeLimit: 'Max 1 MB',
    targetSize: 1,
    unit: 'MB',
  },
  {
    name: 'Bank KYC & Statement',
    nameHi: 'बैंक KYC व स्टेटमेंट',
    category: 'Banking',
    sizeLimit: 'Max 2 MB',
    targetSize: 2,
    unit: 'MB',
  },
];

export const GovtGuidelineBadge: React.FC<GovtGuidelineBadgeProps> = ({
  lang,
  onSelectSize,
}) => {
  return (
    <div className="bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-yellow-500/10 dark:from-orange-950/30 dark:via-amber-950/30 dark:to-yellow-950/30 border border-orange-200/80 dark:border-orange-900/50 rounded-2xl p-4 sm:p-5">
      <div className="flex items-center gap-2 mb-2.5">
        <Award className="w-4 h-4 text-orange-600 dark:text-orange-400" />
        <h3 className="font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100">
          {lang === 'hi'
            ? 'सरकारी व प्रतियोगी परीक्षा फॉर्म्स के लिए साइज गाइड'
            : 'Govt & Job Application Form Size Guides'}
        </h3>
      </div>
      <p className="text-xs text-stone-600 dark:text-stone-400 mb-3.5">
        {lang === 'hi'
          ? 'किसी भी कार्ड पर क्लिक करके उस फॉर्म का सटीक KB/MB साइज तुरंत सेट करें:'
          : 'Click any card below to instantly set that portal’s required KB/MB target:'}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {FORM_GUIDELINES.map((guide, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => onSelectSize(guide.targetSize, guide.unit)}
            className="group text-left p-2.5 bg-white/90 dark:bg-stone-900/90 hover:bg-orange-50 dark:hover:bg-orange-950/50 border border-stone-200/90 dark:border-stone-800 hover:border-orange-400 dark:hover:border-orange-700 rounded-xl transition-all shadow-2xs hover:shadow-xs"
          >
            <div className="flex items-center justify-between text-[10px] text-stone-400 mb-1">
              <span>{guide.category}</span>
              <ArrowUpRight className="w-3 h-3 text-stone-400 group-hover:text-orange-600 transition-colors" />
            </div>
            <div className="font-semibold text-xs text-stone-900 dark:text-stone-100 truncate">
              {lang === 'hi' ? guide.nameHi : guide.name}
            </div>
            <div className="text-[11px] font-bold text-orange-600 dark:text-orange-400 mt-1">
              {guide.sizeLimit}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
