import React, { useState } from 'react';
import {
  FileText,
  Image as ImageIcon,
  Download,
  Eye,
  SlidersHorizontal,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ArrowRight,
  Sparkles,
  Copy,
  Check,
} from 'lucide-react';
import { CompressedFileItem } from '../types';
import { TranslationSet } from '../data/translations';
import { formatBytes, calculateSavings, downloadBlob } from '../utils/formatters';

interface FileCardProps {
  item: CompressedFileItem;
  t: TranslationSet;
  lang: 'hi' | 'en';
  onCompressSingle: (id: string) => void;
  onRemove: (id: string) => void;
  onOpenPreview: (item: CompressedFileItem) => void;
  onOpenCompare: (item: CompressedFileItem) => void;
}

export const FileCard: React.FC<FileCardProps> = ({
  item,
  t,
  lang,
  onCompressSingle,
  onRemove,
  onOpenPreview,
  onOpenCompare,
}) => {
  const [copied, setCopied] = useState(false);

  const savings =
    item.compressedSize !== undefined
      ? calculateSavings(item.originalSize, item.compressedSize)
      : null;

  const handleCopyImage = async () => {
    if (!item.compressedBlob || item.type !== 'image') return;
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        const pngBlob =
          item.compressedBlob.type === 'image/png'
            ? item.compressedBlob
            : await (async () => {
                // Convert blob to PNG for standard clipboard support
                const img = new Image();
                const url = URL.createObjectURL(item.compressedBlob!);
                await new Promise((res) => {
                  img.onload = res;
                  img.src = url;
                });
                const canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0);
                URL.revokeObjectURL(url);
                return new Promise<Blob>((res) =>
                  canvas.toBlob((b) => res(b!), 'image/png')
                );
              })();

        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': pngBlob }),
        ]);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleDownload = () => {
    if (!item.compressedBlob) return;
    const ext = item.type === 'pdf' ? '.pdf' : item.compressedBlob.type.includes('png') ? '.png' : item.compressedBlob.type.includes('webp') ? '.webp' : '.jpg';
    const nameWithoutExt = item.name.replace(/\.[^/.]+$/, '');
    const filename = `${nameWithoutExt}_compressed${ext}`;
    downloadBlob(item.compressedBlob, filename);
  };

  return (
    <div
      id={`file-card-${item.id}`}
      className={`relative bg-white dark:bg-stone-900 border rounded-2xl p-4 transition-all duration-200 shadow-xs ${
        item.status === 'completed'
          ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/10 dark:bg-emerald-950/10'
          : item.status === 'compressing'
          ? 'border-orange-300 dark:border-orange-800 ring-2 ring-orange-500/20'
          : item.status === 'error'
          ? 'border-red-200 dark:border-red-900/60'
          : 'border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
      }`}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left: Thumbnail and File Meta */}
        <div className="flex items-center gap-3.5 min-w-0 flex-1">
          {/* Thumbnail / Icon */}
          <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 shrink-0 flex items-center justify-center">
            {item.compressedPreviewUrl || item.originalPreviewUrl ? (
              <img
                src={item.compressedPreviewUrl || item.originalPreviewUrl}
                alt={item.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : item.type === 'pdf' ? (
              <FileText className="w-7 h-7 text-red-500" />
            ) : (
              <ImageIcon className="w-7 h-7 text-blue-500" />
            )}

            {/* Type badge */}
            <span
              className={`absolute bottom-0 inset-x-0 text-[9px] font-bold text-center text-white py-0.5 uppercase tracking-wider ${
                item.type === 'pdf' ? 'bg-red-600/90' : 'bg-blue-600/90'
              }`}
            >
              {item.type}
            </span>
          </div>

          {/* Name & Size Information */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h4
                className="font-semibold text-sm text-stone-900 dark:text-stone-100 truncate"
                title={item.name}
              >
                {item.name}
              </h4>
              {item.pageCount && item.pageCount > 1 && (
                <span className="text-[10px] font-medium bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 px-1.5 py-0.5 rounded-md shrink-0">
                  {item.pageCount} {t.pages}
                </span>
              )}
            </div>

            {/* Size badges row */}
            <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs">
              {/* Original size */}
              <span className="text-stone-500 dark:text-stone-400">
                {t.original}:{' '}
                <span className="font-semibold text-stone-700 dark:text-stone-300">
                  {formatBytes(item.originalSize)}
                </span>
              </span>

              {/* Compressed size result */}
              {item.status === 'completed' && item.compressedSize !== undefined && (
                <>
                  <ArrowRight className="w-3 h-3 text-stone-400" />
                  <span className="text-stone-900 dark:text-stone-100 font-bold bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded-md border border-emerald-300/60 dark:border-emerald-800/60">
                    {formatBytes(item.compressedSize)}
                  </span>

                  {savings && (
                    <span className="font-bold text-xs text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md">
                      -{savings.percentage.toFixed(1)}% {t.saved}
                    </span>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right: Status and Action Buttons */}
        <div className="flex items-center flex-wrap gap-2 justify-end">
          {/* Progress state */}
          {item.status === 'compressing' && (
            <div className="flex items-center gap-2 text-xs font-semibold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-3 py-1.5 rounded-xl border border-orange-200 dark:border-orange-800">
              <Loader2 className="w-4 h-4 animate-spin text-orange-600" />
              <span>{item.progress}% {t.compressing}</span>
            </div>
          )}

          {/* Error State */}
          {item.status === 'error' && (
            <div className="flex items-center gap-1.5 text-xs text-red-600 bg-red-50 dark:bg-red-950/50 px-2.5 py-1 rounded-lg">
              <AlertCircle className="w-4 h-4" />
              <span>{item.errorMessage || t.errorProcessing}</span>
            </div>
          )}

          {/* Completed State Actions */}
          {item.status === 'completed' && (
            <>
              {/* Compare Button (for images) */}
              {item.type === 'image' && item.originalPreviewUrl && (
                <button
                  type="button"
                  onClick={() => onOpenCompare(item)}
                  className="px-2.5 py-1.5 text-xs font-medium bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 rounded-lg transition-colors flex items-center gap-1 border border-stone-200 dark:border-stone-700"
                  title="Compare Before & After"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{t.compare}</span>
                </button>
              )}

              {/* Preview Button (for PDF or image) */}
              <button
                type="button"
                onClick={() => onOpenPreview(item)}
                className="px-2.5 py-1.5 text-xs font-medium bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 rounded-lg transition-colors flex items-center gap-1 border border-stone-200 dark:border-stone-700"
                title="Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.preview}</span>
              </button>

              {/* Copy image to clipboard */}
              {item.type === 'image' && (
                <button
                  type="button"
                  onClick={handleCopyImage}
                  className="p-1.5 text-xs font-medium bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 rounded-lg transition-colors border border-stone-200 dark:border-stone-700"
                  title="Copy image to clipboard"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              )}

              {/* Download Button */}
              <button
                type="button"
                onClick={handleDownload}
                className="px-3.5 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.download}</span>
              </button>
            </>
          )}

          {/* Idle / Error State Compress Button */}
          {(item.status === 'idle' || item.status === 'error') && (
            <button
              type="button"
              onClick={() => onCompressSingle(item.id)}
              className="px-3.5 py-1.5 text-xs font-semibold bg-orange-600 hover:bg-orange-500 text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.compressNow}</span>
            </button>
          )}

          {/* Delete File Button */}
          <button
            type="button"
            onClick={() => onRemove(item.id)}
            className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
            title="Remove"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Bar for compressing state */}
      {item.status === 'compressing' && (
        <div className="w-full bg-stone-100 dark:bg-stone-800 h-1.5 rounded-full overflow-hidden mt-3">
          <div
            className="bg-orange-500 h-full transition-all duration-300 rounded-full"
            style={{ width: `${Math.max(5, item.progress)}%` }}
          />
        </div>
      )}
    </div>
  );
};
