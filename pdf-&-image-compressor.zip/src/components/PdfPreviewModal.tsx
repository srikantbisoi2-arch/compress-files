import React from 'react';
import { X, Download, FileText, ArrowRight } from 'lucide-react';
import { CompressedFileItem } from '../types';
import { TranslationSet } from '../data/translations';
import { formatBytes, calculateSavings, downloadBlob } from '../utils/formatters';

interface PdfPreviewModalProps {
  item: CompressedFileItem | null;
  t: TranslationSet;
  lang: 'hi' | 'en';
  onClose: () => void;
}

export const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  item,
  t,
  lang,
  onClose,
}) => {
  if (!item) return null;

  const savings =
    item.compressedSize !== undefined
      ? calculateSavings(item.originalSize, item.compressedSize)
      : null;

  const handleDownload = () => {
    if (!item.compressedBlob) return;
    const nameWithoutExt = item.name.replace(/\.[^/.]+$/, '');
    downloadBlob(item.compressedBlob, `${nameWithoutExt}_compressed.pdf`);
  };

  const previewUrl = item.compressedPreviewUrl || item.originalPreviewUrl;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-800 bg-stone-900 text-white">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-red-500" />
            <h3 className="font-semibold text-sm truncate max-w-xs sm:max-w-md">
              {item.name}
            </h3>
            {savings && (
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-full">
                -{savings.percentage.toFixed(1)}% {t.saved}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 min-h-[400px] max-h-[65vh] bg-stone-950 p-4 flex items-center justify-center overflow-auto">
          {previewUrl ? (
            item.compressedBlob && item.compressedBlob.type === 'application/pdf' ? (
              <iframe
                src={`${previewUrl}#toolbar=0`}
                className="w-full h-full min-h-[450px] rounded-lg border border-stone-800 bg-white"
                title="PDF Preview"
              />
            ) : (
              <img
                src={previewUrl}
                alt="PDF page preview"
                className="max-h-[55vh] max-w-full object-contain rounded-lg shadow-lg"
                referrerPolicy="no-referrer"
              />
            )
          ) : (
            <div className="text-center text-stone-400 p-8">
              <FileText className="w-16 h-16 mx-auto mb-3 text-stone-600" />
              <p>{item.name}</p>
              <p className="text-xs text-stone-500 mt-1">
                {item.pageCount ? `${item.pageCount} ${t.pages}` : ''}
              </p>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-5 py-3.5 border-t border-stone-800 bg-stone-900 text-xs">
          <div className="flex items-center gap-3 text-stone-300">
            <span>
              {t.original}: <strong>{formatBytes(item.originalSize)}</strong>
            </span>
            {item.compressedSize !== undefined && (
              <>
                <ArrowRight className="w-3.5 h-3.5 text-stone-500" />
                <span className="text-emerald-400 font-bold">
                  {t.compressed}: {formatBytes(item.compressedSize)}
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 font-medium"
            >
              {lang === 'hi' ? 'बंद करें' : 'Close'}
            </button>
            {item.compressedBlob && (
              <button
                type="button"
                onClick={handleDownload}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.download}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
