import React, { useState } from 'react';
import { Sliders, Sparkles, HelpCircle, ChevronDown, ChevronUp, Layers, Check, Info } from 'lucide-react';
import { CompressionOptions, TargetUnit } from '../types';
import { TranslationSet } from '../data/translations';
import { POPULAR_PRESETS } from '../data/presets';

interface TargetSizeControlProps {
  t: TranslationSet;
  lang: 'hi' | 'en';
  options: CompressionOptions;
  setOptions: React.Dispatch<React.SetStateAction<CompressionOptions>>;
  onApplyToAll?: () => void;
  filesCount: number;
}

export const TargetSizeControl: React.FC<TargetSizeControlProps> = ({
  t,
  lang,
  options,
  setOptions,
  filesCount,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleUnitChange = (unit: TargetUnit) => {
    // If switching from MB to KB or vice versa, adjust value sensibly
    let newTarget = options.targetSizeValue;
    if (options.targetSizeUnit === 'MB' && unit === 'KB') {
      newTarget = Math.round(options.targetSizeValue * 1024);
    } else if (options.targetSizeUnit === 'KB' && unit === 'MB') {
      newTarget = parseFloat((options.targetSizeValue / 1024).toFixed(2));
      if (newTarget < 0.1) newTarget = 0.5;
    }

    setOptions((prev) => ({
      ...prev,
      targetSizeUnit: unit,
      targetSizeValue: newTarget,
    }));
  };

  const handlePresetSelect = (presetSize: number, unit: TargetUnit) => {
    setOptions((prev) => ({
      ...prev,
      mode: 'target_size',
      targetSizeValue: presetSize,
      targetSizeUnit: unit,
    }));
  };

  return (
    <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
      {/* Header with Mode Selection */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-100 dark:border-stone-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/70 text-orange-600 dark:text-orange-400 flex items-center justify-center">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-bold text-stone-900 dark:text-stone-100 text-sm sm:text-base">
              {t.targetSizeLabel}
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {t.targetSizeHelp}
            </p>
          </div>
        </div>

        {/* Compression Strategy Tabs */}
        <div className="flex items-center bg-stone-100 dark:bg-stone-800/80 p-1 rounded-xl text-xs font-semibold">
          <button
            type="button"
            id="tab-mode-target-size"
            onClick={() => setOptions((p) => ({ ...p, mode: 'target_size' }))}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              options.mode === 'target_size'
                ? 'bg-white dark:bg-stone-900 text-orange-600 dark:text-orange-400 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            {t.targetSizeMode}
          </button>
          <button
            type="button"
            id="tab-mode-percentage"
            onClick={() => setOptions((p) => ({ ...p, mode: 'percentage' }))}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              options.mode === 'percentage'
                ? 'bg-white dark:bg-stone-900 text-orange-600 dark:text-orange-400 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            {t.percentageMode}
          </button>
          <button
            type="button"
            id="tab-mode-quality"
            onClick={() => setOptions((p) => ({ ...p, mode: 'quality_manual' }))}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              options.mode === 'quality_manual'
                ? 'bg-white dark:bg-stone-900 text-orange-600 dark:text-orange-400 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            {t.qualityMode}
          </button>
        </div>
      </div>

      {/* Main Mode Body */}
      <div className="pt-4 space-y-4">
        {/* EXACT KB / MB INPUT MODE */}
        {options.mode === 'target_size' && (
          <div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Numeric Input + KB/MB Selector */}
              <div className="flex-1 flex items-center bg-stone-50 dark:bg-stone-800/60 border-2 border-orange-500/80 focus-within:border-orange-500 rounded-xl px-4 py-2.5 shadow-xs transition-colors">
                <input
                  type="number"
                  id="target-size-input"
                  min={options.targetSizeUnit === 'KB' ? 10 : 0.05}
                  max={options.targetSizeUnit === 'KB' ? 102400 : 100}
                  step={options.targetSizeUnit === 'KB' ? 10 : 0.1}
                  value={options.targetSizeValue}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (!isNaN(val) && val > 0) {
                      setOptions((prev) => ({ ...prev, targetSizeValue: val }));
                    }
                  }}
                  className="w-full bg-transparent font-bold text-2xl text-stone-900 dark:text-white focus:outline-hidden"
                  placeholder="e.g. 200"
                />

                {/* Unit Switcher Button Group */}
                <div className="flex items-center gap-1 bg-white dark:bg-stone-900 p-1 rounded-lg border border-stone-200 dark:border-stone-700 shadow-2xs ml-3">
                  <button
                    type="button"
                    id="unit-kb-btn"
                    onClick={() => handleUnitChange('KB')}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                      options.targetSizeUnit === 'KB'
                        ? 'bg-orange-600 text-white shadow-xs'
                        : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
                    }`}
                  >
                    KB
                  </button>
                  <button
                    type="button"
                    id="unit-mb-btn"
                    onClick={() => handleUnitChange('MB')}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                      options.targetSizeUnit === 'MB'
                        ? 'bg-orange-600 text-white shadow-xs'
                        : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
                    }`}
                  >
                    MB
                  </button>
                </div>
              </div>

              {/* Target Size Indicator Pill */}
              <div className="flex items-center justify-between sm:justify-start gap-2 text-xs bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 text-amber-900 dark:text-amber-300 px-3.5 py-3 rounded-xl">
                <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                <span>
                  {lang === 'hi' ? 'आउटपुट अधिकतम' : 'Output capped at'}{' '}
                  <strong>
                    {options.targetSizeValue} {options.targetSizeUnit}
                  </strong>
                </span>
              </div>
            </div>

            {/* Quick Presets Pills */}
            <div className="mt-3.5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-stone-600 dark:text-stone-400 flex items-center gap-1">
                  {t.presetsTitle}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {POPULAR_PRESETS.map((preset) => {
                  const isSelected =
                    options.targetSizeValue === preset.targetSize &&
                    options.targetSizeUnit === preset.unit;

                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handlePresetSelect(preset.targetSize, preset.unit)}
                      className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                          : 'bg-stone-50 dark:bg-stone-800/80 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:border-orange-300 hover:bg-orange-50/50 dark:hover:bg-stone-800'
                      }`}
                      title={lang === 'hi' ? preset.descriptionHi : preset.description}
                    >
                      {isSelected && <Check className="w-3 h-3 text-white" />}
                      <span>{lang === 'hi' ? preset.labelHi : preset.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* PERCENTAGE MODE */}
        {options.mode === 'percentage' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-stone-700 dark:text-stone-300">
                {lang === 'hi' ? 'कंप्रेशन लेवल (प्रतिशत)' : 'Compression Level (%)'}
              </span>
              <span className="text-sm font-bold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-2.5 py-0.5 rounded-md border border-orange-200 dark:border-orange-800/50">
                {options.percentage}% {lang === 'hi' ? 'कम होगा' : 'Reduction'}
              </span>
            </div>
            <input
              type="range"
              min={10}
              max={95}
              step={5}
              value={options.percentage}
              onChange={(e) =>
                setOptions((prev) => ({ ...prev, percentage: parseInt(e.target.value, 10) }))
              }
              className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-orange-600"
            />
            <div className="flex justify-between text-[11px] text-stone-400">
              <span>10% (Low Reduction)</span>
              <span>50% (Recommended)</span>
              <span>90% (Maximum Reduction)</span>
            </div>
          </div>
        )}

        {/* MANUAL QUALITY MODE */}
        {options.mode === 'quality_manual' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-stone-700 dark:text-stone-300">
                {lang === 'hi' ? 'इमेज/डॉक्यूमेंट क्वालिटी' : 'Quality Ratio'}
              </span>
              <span className="text-sm font-bold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-2.5 py-0.5 rounded-md border border-orange-200 dark:border-orange-800/50">
                {Math.round(options.quality * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.1}
              max={1.0}
              step={0.05}
              value={options.quality}
              onChange={(e) =>
                setOptions((prev) => ({ ...prev, quality: parseFloat(e.target.value) }))
              }
              className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-orange-600"
            />
            <div className="flex justify-between text-[11px] text-stone-400">
              <span>10% (Smallest File)</span>
              <span>75% (Balanced)</span>
              <span>100% (High Quality)</span>
            </div>
          </div>
        )}

        {/* Advanced Options Toggle */}
        <div className="pt-2 border-t border-stone-100 dark:border-stone-800">
          <button
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center justify-between w-full text-xs font-semibold text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white py-1"
          >
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-stone-500" />
              {lang === 'hi' ? 'अतिरिक्त सेटिंग्स (Advanced Options)' : 'Advanced Options & Formats'}
            </span>
            {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showAdvanced && (
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-4 p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200/70 dark:border-stone-800 text-xs">
              {/* Output Image Format */}
              <div>
                <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                  {t.formatOption} (Images)
                </label>
                <select
                  value={options.outputFormat || 'original'}
                  onChange={(e) =>
                    setOptions((prev) => ({
                      ...prev,
                      outputFormat: e.target.value as any,
                    }))
                  }
                  className="w-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg px-2.5 py-1.5 text-stone-800 dark:text-stone-200"
                >
                  <option value="original">{t.originalFormat}</option>
                  <option value="image/jpeg">JPG / JPEG (Best for photos & forms)</option>
                  <option value="image/webp">WebP (Modern ultra-small format)</option>
                  <option value="image/png">PNG (Lossless / Graphics)</option>
                </select>
              </div>

              {/* PDF Compression Mode */}
              <div>
                <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                  PDF Processing Strategy
                </label>
                <select
                  value={options.pdfMode || 'render_resample'}
                  onChange={(e) =>
                    setOptions((prev) => ({
                      ...prev,
                      pdfMode: e.target.value as any,
                    }))
                  }
                  className="w-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg px-2.5 py-1.5 text-stone-800 dark:text-stone-200"
                >
                  <option value="render_resample">
                    Strict KB/MB Resampling (Hits exact size for forms)
                  </option>
                  <option value="smart_stream">
                    Smart Vector (Keeps text vector, strips unused metadata)
                  </option>
                </select>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
