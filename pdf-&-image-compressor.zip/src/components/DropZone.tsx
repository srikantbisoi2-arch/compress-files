import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, FileText, Image as ImageIcon, Plus, Zap } from 'lucide-react';
import { TranslationSet } from '../data/translations';

interface DropZoneProps {
  t: TranslationSet;
  onFilesSelected: (files: File[]) => void;
  hasFiles: boolean;
}

export const DropZone: React.FC<DropZoneProps> = ({
  t,
  onFilesSelected,
  hasFiles,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Paste support from clipboard
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      const pastedFiles: File[] = [];

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.kind === 'file') {
          const file = item.getAsFile();
          if (file && (file.type.startsWith('image/') || file.type === 'application/pdf')) {
            pastedFiles.push(file);
          }
        }
      }

      if (pastedFiles.length > 0) {
        onFilesSelected(pastedFiles);
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [onFilesSelected]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesList = Array.from(e.dataTransfer.files) as File[];
      const validFiles = filesList.filter(
        (f: File) => f.type.startsWith('image/') || f.type === 'application/pdf' || f.name.endsWith('.pdf')
      );
      if (validFiles.length > 0) {
        onFilesSelected(validFiles);
      }
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesList = Array.from(e.target.files) as File[];
      onFilesSelected(filesList);
      // Reset input value so same file can be re-uploaded if desired
      e.target.value = '';
    }
  };

  // Helper to load a sample image for quick testing
  const handleLoadSample = async () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 2400;
      canvas.height = 1600;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Create an attractive rich sample certificate / photo
        const grad = ctx.createLinearGradient(0, 0, 2400, 1600);
        grad.addColorStop(0, '#1e293b');
        grad.addColorStop(0.5, '#3b82f6');
        grad.addColorStop(1, '#065f46');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 2400, 1600);

        // Add some sample graphic elements
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        for (let i = 0; i < 25; i++) {
          ctx.beginPath();
          ctx.arc(Math.random() * 2400, Math.random() * 1600, Math.random() * 120 + 30, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 84px system-ui, sans-serif';
        ctx.fillText('Sample Document / Photo (High Res)', 200, 400);

        ctx.font = '40px system-ui, sans-serif';
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.fillText('Resolution: 2400 x 1600px • Test Custom Target KB/MB Compression', 200, 520);
        ctx.fillText('Ready for instant resize to 50KB, 100KB, 200KB, 500KB or custom size!', 200, 600);
      }

      canvas.toBlob((blob) => {
        if (blob) {
          const sampleFile = new File([blob], 'Sample_HighRes_Photo.jpg', { type: 'image/jpeg' });
          onFilesSelected([sampleFile]);
        }
      }, 'image/jpeg', 0.98);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div
      id="file-dropzone-container"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
      className={`relative group cursor-pointer transition-all duration-200 rounded-2xl border-2 border-dashed ${
        isDragging
          ? 'border-orange-500 bg-orange-50/70 dark:bg-orange-950/30 scale-[1.008]'
          : hasFiles
          ? 'border-stone-300 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/30 hover:border-orange-400 dark:hover:border-orange-500 py-6 px-6'
          : 'border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800/40 hover:border-orange-400 dark:hover:border-orange-500 py-10 sm:py-14 px-6 shadow-sm'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".pdf,image/jpeg,image/png,image/webp,image/gif,image/bmp,image/svg+xml,.jpg,.jpeg,.png,.webp"
        onChange={handleFileInput}
        className="hidden"
        id="file-input-element"
      />

      <div className="flex flex-col items-center text-center">
        {/* Upload Icon */}
        <div
          className={`rounded-2xl flex items-center justify-center transition-all ${
            hasFiles
              ? 'w-12 h-12 mb-3 bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400'
              : 'w-16 h-16 mb-4 bg-gradient-to-tr from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-500/25 group-hover:scale-105'
          }`}
        >
          {hasFiles ? <Plus className="w-6 h-6" /> : <UploadCloud className="w-8 h-8" />}
        </div>

        {/* Title */}
        <h3 className={`font-bold text-stone-800 dark:text-stone-100 ${hasFiles ? 'text-base' : 'text-lg sm:text-xl'}`}>
          {hasFiles ? t.addMoreFiles : t.dropzoneTitle}
        </h3>

        {/* Subtitle */}
        <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-1 max-w-md">
          {t.dropzoneDesc}
        </p>

        {/* Supported badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-[11px] font-medium text-stone-600 dark:text-stone-300">
          <span className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 px-2.5 py-1 rounded-md border border-stone-200/80 dark:border-stone-700">
            <FileText className="w-3.5 h-3.5 text-red-500" />
            PDF Documents
          </span>
          <span className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 px-2.5 py-1 rounded-md border border-stone-200/80 dark:border-stone-700">
            <ImageIcon className="w-3.5 h-3.5 text-blue-500" />
            JPG, PNG, WebP
          </span>
          <span className="bg-stone-100 dark:bg-stone-800 px-2 py-1 rounded-md border border-stone-200/80 dark:border-stone-700 text-stone-500 dark:text-stone-400">
            Ctrl+V Paste Supported
          </span>
        </div>

        {/* Primary Action Button */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 active:bg-orange-700 text-white font-semibold text-sm shadow-md shadow-orange-600/20 transition-all flex items-center gap-2"
          >
            <UploadCloud className="w-4 h-4" />
            {t.selectFiles}
          </button>

          {!hasFiles && (
            <button
              type="button"
              id="try-sample-btn"
              onClick={(e) => {
                e.stopPropagation();
                handleLoadSample();
              }}
              className="px-3.5 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 font-medium text-xs transition-colors flex items-center gap-1.5 border border-stone-200 dark:border-stone-700"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              Try Demo Sample
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
