import React, { useState, useRef, useEffect } from 'react';
import { X, ZoomIn, ZoomOut, RotateCcw, Download, Sparkles } from 'lucide-react';
import { CompressedFileItem } from '../types';
import { TranslationSet } from '../data/translations';
import { formatBytes, calculateSavings, downloadBlob } from '../utils/formatters';

interface ImageComparisonModalProps {
  item: CompressedFileItem | null;
  t: TranslationSet;
  lang: 'hi' | 'en';
  onClose: () => void;
}

export const ImageComparisonModal: React.FC<ImageComparisonModalProps> = ({
  item,
  t,
  lang,
  onClose,
}) => {
  const [sliderPosition, setSliderPosition] = useState(50); // percentage 0 - 100
  const [zoom, setZoom] = useState(1);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);

  if (!item || !item.originalPreviewUrl || !item.compressedPreviewUrl) {
    return null;
  }

  const savings =
    item.compressedSize !== undefined
      ? calculateSavings(item.originalSize, item.compressedSize)
      : null;

  const handlePointerDown = () => {
    isDraggingRef.current = true;
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  const handleDownload = () => {
    if (!item.compressedBlob) return;
    const ext = item.compressedBlob.type.includes('png')
      ? '.png'
      : item.compressedBlob.type.includes('webp')
      ? '.webp'
      : '.jpg';
    const nameWithoutExt = item.name.replace(/\.[^/.]+$/, '');
    downloadBlob(item.compressedBlob, `${nameWithoutExt}_compressed${ext}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl"
        onPointerUp={handlePointerUp}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-800 bg-stone-900/90 text-white">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-sm truncate max-w-xs sm:max-w-md">
              {item.name} — {lang === 'hi' ? 'क्वालिटी तुलना' : 'Quality Comparison'}
            </h3>
            {savings && (
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-full">
                -{savings.percentage.toFixed(1)}% {t.saved}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Zoom Controls */}
            <div className="flex items-center bg-stone-800 rounded-lg p-0.5 border border-stone-700">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1 text-stone-300 hover:text-white rounded hover:bg-stone-700"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs px-1.5 text-stone-400 font-mono">{Math.round(zoom * 100)}%</span>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
                className="p-1 text-stone-300 hover:text-white rounded hover:bg-stone-700"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoom(1)}
                className="p-1 text-stone-300 hover:text-white rounded hover:bg-stone-700 ml-0.5"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Split-Comparison Canvas */}
        <div
          ref={containerRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          className="relative flex-1 min-h-[360px] max-h-[60vh] bg-stone-950 select-none overflow-hidden cursor-ew-resize flex items-center justify-center p-4"
        >
          <div
            className="relative transition-transform duration-75 flex items-center justify-center"
            style={{ transform: `scale(${zoom})` }}
          >
            {/* Compressed Image (Right / Base) */}
            <img
              src={item.compressedPreviewUrl}
              alt="Compressed"
              className="max-h-[50vh] max-w-full object-contain pointer-events-none rounded-lg"
              referrerPolicy="no-referrer"
            />

            {/* Original Image (Left / Clipped overlay) */}
            <div
              className="absolute inset-0 overflow-hidden pointer-events-none"
              style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
            >
              <img
                src={item.originalPreviewUrl}
                alt="Original"
                className="max-h-[50vh] max-w-full object-contain pointer-events-none rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Split Divider Line */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg pointer-events-none z-10"
              style={{ left: `${sliderPosition}%` }}
            >
              {/* Center Handle */}
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white text-stone-900 shadow-xl flex items-center justify-center text-xs font-bold font-mono">
                ↔
              </div>
            </div>
          </div>

          {/* Floating Badges */}
          <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-md border border-white/20">
            {lang === 'hi' ? 'ओरिजिनल (Original)' : 'Original'}: {formatBytes(item.originalSize)}
          </div>
          <div className="absolute top-3 right-3 bg-emerald-950/80 backdrop-blur-xs text-emerald-300 text-xs font-semibold px-2.5 py-1 rounded-md border border-emerald-500/30">
            {lang === 'hi' ? 'कंप्रेस्ड (Compressed)' : 'Compressed'}:{' '}
            {item.compressedSize ? formatBytes(item.compressedSize) : ''}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-stone-800 bg-stone-900 text-xs text-stone-400">
          <div>
            {lang === 'hi'
              ? 'स्लाइडर को लेफ्ट/राइट खींचकर क्वालिटी चेक करें'
              : 'Drag the split slider left or right to inspect compressed pixel sharpness'}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200"
            >
              {lang === 'hi' ? 'बंद करें' : 'Close'}
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t.download}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
