export type FileType = 'image' | 'pdf';

export type TargetUnit = 'KB' | 'MB';

export interface CompressionOptions {
  mode: 'target_size' | 'percentage' | 'quality_manual';
  targetSizeValue: number; // e.g. 500
  targetSizeUnit: TargetUnit; // 'KB' | 'MB'
  percentage: number; // 1-100
  quality: number; // 0.1 - 1.0
  maxWidthOrHeight?: number;
  outputFormat?: 'original' | 'image/jpeg' | 'image/webp' | 'image/png';
  pdfMode?: 'smart_stream' | 'render_resample'; // smart vector vs render resample
  removeMetadata?: boolean;
}

export interface CompressedFileItem {
  id: string;
  file: File;
  name: string;
  type: FileType;
  mimeType: string;
  originalSize: number; // in bytes
  originalPreviewUrl?: string;
  pageCount?: number;
  width?: number;
  height?: number;

  status: 'idle' | 'compressing' | 'completed' | 'error';
  progress: number; // 0 to 100
  errorMessage?: string;

  // Custom compression settings per file or inherited
  customOptions?: CompressionOptions;

  // Results
  compressedBlob?: Blob;
  compressedSize?: number; // in bytes
  compressedPreviewUrl?: string;
  compressionRatio?: number; // e.g. -65%
  processingTimeMs?: number;
}

export interface PresetTarget {
  id: string;
  label: string;
  labelHi: string;
  targetSize: number;
  unit: TargetUnit;
  description: string;
  descriptionHi: string;
  icon?: string;
  category: 'common' | 'govt' | 'fast';
}
