import * as pdfjsLib from 'pdfjs-dist';
import { PDFDocument } from 'pdf-lib';
import jsPDF from 'jspdf';
import { CompressionOptions } from '../types';
import { targetToBytes } from './formatters';

// Set up pdf.js worker using CDN for reliable bundle-free execution in preview
if (typeof window !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

export interface CompressPdfResult {
  blob: Blob;
  previewUrl: string;
  size: number;
  pageCount: number;
}

/**
 * Gets PDF page count and first page preview
 */
export async function inspectPdf(file: File): Promise<{ pageCount: number; previewUrl?: string }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdfDoc = await loadingTask.promise;
    const pageCount = pdfDoc.numPages;

    // Render first page for thumbnail preview
    let previewUrl: string | undefined;
    try {
      const page = await pdfDoc.getPage(1);
      const viewport = page.getViewport({ scale: 0.5 });
      const canvas = document.createElement('canvas');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        await page.render({ canvasContext: ctx, viewport }).promise;
        previewUrl = canvas.toDataURL('image/jpeg', 0.8);
      }
    } catch {
      // preview thumbnail optional
    }

    return { pageCount, previewUrl };
  } catch (error) {
    console.warn('PDF inspect fallback via pdf-lib:', error);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
      return { pageCount: pdf.getPageCount() };
    } catch {
      return { pageCount: 1 };
    }
  }
}

/**
 * Smart Vector & Stream Compression using PDF-Lib (preserves vector text, strips metadata, optimizes streams)
 */
async function compressPdfVector(file: File): Promise<Blob> {
  const arrayBuffer = await file.arrayBuffer();
  const pdfDoc = await PDFDocument.load(arrayBuffer, {
    ignoreEncryption: true,
    updateMetadata: false,
  });

  // Strip non-essential metadata
  pdfDoc.setTitle('');
  pdfDoc.setAuthor('');
  pdfDoc.setSubject('');
  pdfDoc.setKeywords([]);
  pdfDoc.setProducer('PDF Compressor');
  pdfDoc.setCreator('PDF Compressor');

  // Save with objects compressed
  const compressedBytes = await pdfDoc.save({
    useObjectStreams: true,
    addDefaultPage: false,
  });

  return new Blob([compressedBytes], { type: 'application/pdf' });
}

/**
 * Target Size Resampling PDF Compression
 * Renders pages at calibrated DPI and JPEG compression to hit custom target KB / MB
 */
async function compressPdfToTargetSize(
  file: File,
  targetBytes: number,
  onProgress?: (progress: number) => void
): Promise<Blob> {
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdfDoc = await loadingTask.promise;
  const numPages = pdfDoc.numPages;

  onProgress?.(15);

  // Budget per page in bytes
  // Give ~5-10% allowance for PDF headers and structure
  const usableBudget = Math.max(1024 * 5, targetBytes * 0.9);
  const budgetPerPage = usableBudget / numPages;

  // Calibrate initial DPI scale & JPEG quality based on target budget
  let scale = 1.2;
  let quality = 0.75;

  if (budgetPerPage < 25 * 1024) { // < 25KB per page (e.g. UPSC/Govt forms 50-100KB for multi-page)
    scale = 0.85;
    quality = 0.45;
  } else if (budgetPerPage < 75 * 1024) { // < 75KB per page
    scale = 1.0;
    quality = 0.65;
  } else if (budgetPerPage < 200 * 1024) { // < 200KB per page
    scale = 1.25;
    quality = 0.78;
  } else {
    scale = 1.5;
    quality = 0.88;
  }

  // Render pages to image data
  const pageImages: { dataUrl: string; width: number; height: number }[] = [];

  for (let i = 1; i <= numPages; i++) {
    const page = await pdfDoc.getPage(i);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport }).promise;
    }

    const dataUrl = canvas.toDataURL('image/jpeg', quality);
    pageImages.push({
      dataUrl,
      width: viewport.width,
      height: viewport.height,
    });

    onProgress?.(15 + Math.round((i / numPages) * 60));
  }

  // Assemble new PDF with jsPDF
  let doc: jsPDF | null = null;

  for (let i = 0; i < pageImages.length; i++) {
    const page = pageImages[i];
    const isLandscape = page.width > page.height;
    const orientation = isLandscape ? 'landscape' : 'portrait';

    if (i === 0) {
      doc = new jsPDF({
        orientation,
        unit: 'pt',
        format: [page.width, page.height],
        compress: true,
      });
    } else if (doc) {
      doc.addPage([page.width, page.height], orientation);
    }

    if (doc) {
      doc.addImage(page.dataUrl, 'JPEG', 0, 0, page.width, page.height, undefined, 'FAST');
    }
  }

  onProgress?.(88);

  if (!doc) {
    throw new Error('Failed to generate compressed PDF document');
  }

  const pdfOutput = doc.output('blob');

  // If output is still larger than targetBytes and we can shrink further, do a quick lower-pass
  if (pdfOutput.size > targetBytes && (quality > 0.35 || scale > 0.75)) {
    onProgress?.(92);
    const reducedDoc = new jsPDF({
      orientation: pageImages[0].width > pageImages[0].height ? 'landscape' : 'portrait',
      unit: 'pt',
      format: [pageImages[0].width * 0.75, pageImages[0].height * 0.75],
      compress: true,
    });

    for (let i = 0; i < pageImages.length; i++) {
      const p = pageImages[i];
      if (i > 0) {
        reducedDoc.addPage([p.width * 0.75, p.height * 0.75], p.width > p.height ? 'landscape' : 'portrait');
      }
      reducedDoc.addImage(p.dataUrl, 'JPEG', 0, 0, p.width * 0.75, p.height * 0.75, undefined, 'FAST');
    }
    const reducedBlob = reducedDoc.output('blob');
    if (reducedBlob.size < pdfOutput.size) {
      return reducedBlob;
    }
  }

  return pdfOutput;
}

/**
 * Main PDF Compression Entry Point
 */
export async function compressPdf(
  file: File,
  options: CompressionOptions,
  onProgress?: (progress: number) => void
): Promise<CompressPdfResult> {
  onProgress?.(10);
  const { pageCount } = await inspectPdf(file);

  let resultBlob: Blob;

  if (options.pdfMode === 'smart_stream') {
    onProgress?.(40);
    resultBlob = await compressPdfVector(file);
    onProgress?.(90);
  } else if (options.mode === 'percentage') {
    const targetBytes = Math.round(file.size * (options.percentage / 100));
    resultBlob = await compressPdfToTargetSize(file, targetBytes, onProgress);
  } else {
    // Target Size Mode (e.g. 500 KB or 2 MB)
    const targetBytes = targetToBytes(options.targetSizeValue, options.targetSizeUnit);
    
    // If target size is larger than original, vector optimization is safe
    if (targetBytes >= file.size) {
      resultBlob = await compressPdfVector(file);
    } else {
      resultBlob = await compressPdfToTargetSize(file, targetBytes, onProgress);
    }
  }

  onProgress?.(100);

  return {
    blob: resultBlob,
    previewUrl: URL.createObjectURL(resultBlob),
    size: resultBlob.size,
    pageCount: pageCount || 1,
  };
}
