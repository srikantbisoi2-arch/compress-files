export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';
  if (bytes < 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const safeI = Math.min(i, sizes.length - 1);

  return parseFloat((bytes / Math.pow(k, safeI)).toFixed(dm)) + ' ' + sizes[safeI];
}

export function bytesToTargetUnit(bytes: number, unit: 'KB' | 'MB'): number {
  if (unit === 'KB') {
    return parseFloat((bytes / 1024).toFixed(2));
  }
  return parseFloat((bytes / (1024 * 1024)).toFixed(2));
}

export function targetToBytes(value: number, unit: 'KB' | 'MB'): number {
  if (unit === 'KB') {
    return Math.round(value * 1024);
  }
  return Math.round(value * 1024 * 1024);
}

export function calculateSavings(original: number, compressed: number): {
  ratio: number;
  percentage: number;
  savedBytes: number;
  isSmaller: boolean;
} {
  const diff = original - compressed;
  const percentage = original > 0 ? (diff / original) * 100 : 0;
  return {
    ratio: compressed / (original || 1),
    percentage: Math.max(-100, Math.min(100, percentage)),
    savedBytes: diff,
    isSmaller: compressed < original,
  };
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
