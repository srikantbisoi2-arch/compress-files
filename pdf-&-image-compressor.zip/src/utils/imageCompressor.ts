import { CompressionOptions } from '../types';
import { targetToBytes } from './formatters';

interface CompressImageResult {
  blob: Blob;
  previewUrl: string;
  size: number;
  width: number;
  height: number;
}

/**
 * Loads an image file into an HTMLImageElement
 */
export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image file'));
    };
    img.src = url;
  });
}

/**
 * Creates a canvas with the rendered image at given scale
 */
function drawToCanvas(
  img: HTMLImageElement,
  scale = 1.0,
  maxWidth?: number,
  maxHeight?: number
): HTMLCanvasElement {
  let width = img.naturalWidth * scale;
  let height = img.naturalHeight * scale;

  if (maxWidth && width > maxWidth) {
    height = (height * maxWidth) / width;
    width = maxWidth;
  }

  if (maxHeight && height > maxHeight) {
    width = (width * maxHeight) / height;
    height = maxHeight;
  }

  width = Math.max(1, Math.round(width));
  height = Math.max(1, Math.round(height));

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Fill white background for transparent images converted to JPEG
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, width, height);
  }

  return canvas;
}

/**
 * Converts canvas to Blob with specified format and quality
 */
function canvasToBlob(canvas: HTMLCanvasElement, mimeType: string, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Canvas conversion to blob failed'));
      },
      mimeType,
      quality
    );
  });
}

/**
 * Compresses an image to hit a target size or quality
 */
export async function compressImage(
  file: File,
  options: CompressionOptions,
  onProgress?: (progress: number) => void
): Promise<CompressImageResult> {
  onProgress?.(10);
  const img = await loadImageFromFile(file);
  onProgress?.(30);

  let outputMimeType = file.type;
  if (options.outputFormat && options.outputFormat !== 'original') {
    outputMimeType = options.outputFormat;
  } else if (!['image/jpeg', 'image/webp', 'image/png'].includes(outputMimeType)) {
    outputMimeType = 'image/jpeg';
  }

  // PNG does not support quality parameter in standard canvas.toBlob, so convert to JPEG/WebP if strong compression is needed
  const isLossyFormat = outputMimeType === 'image/jpeg' || outputMimeType === 'image/webp';

  if (options.mode === 'percentage') {
    // Percentage reduction mode
    const factor = Math.max(0.1, Math.min(1.0, options.percentage / 100));
    const targetQuality = Math.max(0.1, factor);
    const canvas = drawToCanvas(img, Math.min(1.0, Math.sqrt(factor) + 0.1), options.maxWidthOrHeight, options.maxWidthOrHeight);
    onProgress?.(70);
    const blob = await canvasToBlob(canvas, outputMimeType, targetQuality);
    onProgress?.(100);
    return {
      blob,
      previewUrl: URL.createObjectURL(blob),
      size: blob.size,
      width: canvas.width,
      height: canvas.height,
    };
  }

  if (options.mode === 'quality_manual') {
    const canvas = drawToCanvas(img, 1.0, options.maxWidthOrHeight, options.maxWidthOrHeight);
    onProgress?.(70);
    const blob = await canvasToBlob(canvas, outputMimeType, options.quality);
    onProgress?.(100);
    return {
      blob,
      previewUrl: URL.createObjectURL(blob),
      size: blob.size,
      width: canvas.width,
      height: canvas.height,
    };
  }

  // --- TARGET SIZE MODE (User typed custom KB / MB) ---
  const targetBytes = targetToBytes(options.targetSizeValue, options.targetSizeUnit);
  
  // If target format was PNG and target is smaller than original, switch to JPEG for achievable compression
  let effectiveMimeType = outputMimeType;
  if (effectiveMimeType === 'image/png' && targetBytes < file.size) {
    effectiveMimeType = 'image/jpeg';
  }

  let minQuality = 0.05;
  let maxQuality = 0.95;
  let currentScale = 1.0;
  let bestBlob: Blob | null = null;
  let bestCanvas: HTMLCanvasElement | null = null;

  // Initial attempt with scale 1.0
  let canvas = drawToCanvas(img, currentScale, options.maxWidthOrHeight, options.maxWidthOrHeight);
  
  // Binary search on quality
  let iterations = 0;
  const maxIterations = 8;

  while (iterations < maxIterations) {
    iterations++;
    const testQuality = (minQuality + maxQuality) / 2;
    const blob = await canvasToBlob(canvas, effectiveMimeType, testQuality);
    
    onProgress?.(30 + Math.round((iterations / (maxIterations + 4)) * 60));

    if (blob.size <= targetBytes) {
      bestBlob = blob;
      bestCanvas = canvas;
      // We are below target, can we get better quality?
      minQuality = testQuality;
    } else {
      // Too big
      maxQuality = testQuality;
    }

    if (Math.abs(blob.size - targetBytes) < targetBytes * 0.05) {
      // Within 5% of target size, great result!
      bestBlob = blob;
      bestCanvas = canvas;
      break;
    }
  }

  // If even at minimum quality (0.05) the image is still larger than targetBytes,
  // we must downscale the resolution.
  if (!bestBlob || bestBlob.size > targetBytes) {
    let scaleDownAttempts = 0;
    while (scaleDownAttempts < 5 && (!bestBlob || bestBlob.size > targetBytes)) {
      scaleDownAttempts++;
      currentScale *= 0.75; // reduce dimensions
      canvas = drawToCanvas(img, currentScale, options.maxWidthOrHeight, options.maxWidthOrHeight);
      
      const blob = await canvasToBlob(canvas, effectiveMimeType, 0.7);
      if (blob.size <= targetBytes) {
        bestBlob = blob;
        bestCanvas = canvas;
        break;
      } else {
        const lowBlob = await canvasToBlob(canvas, effectiveMimeType, 0.35);
        bestBlob = lowBlob;
        bestCanvas = canvas;
        if (lowBlob.size <= targetBytes) break;
      }
    }
  }

  // Fallback if none found
  if (!bestBlob || !bestCanvas) {
    canvas = drawToCanvas(img, 0.5);
    bestBlob = await canvasToBlob(canvas, 'image/jpeg', 0.5);
    bestCanvas = canvas;
  }

  onProgress?.(100);

  return {
    blob: bestBlob,
    previewUrl: URL.createObjectURL(bestBlob),
    size: bestBlob.size,
    width: bestCanvas.width,
    height: bestCanvas.height,
  };
}
