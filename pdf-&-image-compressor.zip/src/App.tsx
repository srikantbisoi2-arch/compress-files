import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { DropZone } from './components/DropZone';
import { TargetSizeControl } from './components/TargetSizeControl';
import { FileCard } from './components/FileCard';
import { BatchSummaryBar } from './components/BatchSummaryBar';
import { GovtGuidelineBadge } from './components/GovtGuidelineBadge';
import { ImageComparisonModal } from './components/ImageComparisonModal';
import { PdfPreviewModal } from './components/PdfPreviewModal';
import { CompressedFileItem, CompressionOptions, TargetUnit } from './types';
import { TRANSLATIONS } from './data/translations';
import { compressImage } from './utils/imageCompressor';
import { compressPdf, inspectPdf } from './utils/pdfCompressor';
import { ShieldCheck, Zap, FileCheck, HelpCircle } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<'hi' | 'en'>('hi');
  const [isDark, setIsDark] = useState<boolean>(false);
  const t = TRANSLATIONS[lang];

  // Global default compression settings
  const [options, setOptions] = useState<CompressionOptions>({
    mode: 'target_size',
    targetSizeValue: 200,
    targetSizeUnit: 'KB',
    percentage: 50,
    quality: 0.75,
    outputFormat: 'original',
    pdfMode: 'render_resample',
  });

  const [files, setFiles] = useState<CompressedFileItem[]>([]);
  const [isCompressingAll, setIsCompressingAll] = useState(false);

  // Modals state
  const [previewItem, setPreviewItem] = useState<CompressedFileItem | null>(null);
  const [compareItem, setCompareItem] = useState<CompressedFileItem | null>(null);

  // Dark mode effect
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Handle files selected from dropzone or file picker
  const handleFilesSelected = async (newRawFiles: File[]) => {
    const newItems: CompressedFileItem[] = [];

    for (const file of newRawFiles) {
      const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
      const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

      let previewUrl: string | undefined;
      let pageCount: number | undefined;

      if (!isPdf && file.type.startsWith('image/')) {
        previewUrl = URL.createObjectURL(file);
      } else if (isPdf) {
        try {
          const inspected = await inspectPdf(file);
          pageCount = inspected.pageCount;
          previewUrl = inspected.previewUrl;
        } catch {
          pageCount = 1;
        }
      }

      newItems.push({
        id,
        file,
        name: file.name,
        type: isPdf ? 'pdf' : 'image',
        mimeType: file.type || (isPdf ? 'application/pdf' : 'image/jpeg'),
        originalSize: file.size,
        originalPreviewUrl: previewUrl,
        pageCount,
        status: 'idle',
        progress: 0,
      });
    }

    setFiles((prev) => [...prev, ...newItems]);
  };

  // Compress a single file
  const compressSingleFile = useCallback(
    async (fileId: string, customOpts?: CompressionOptions) => {
      const currentOpts = customOpts || options;

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId
            ? { ...f, status: 'compressing', progress: 5, errorMessage: undefined }
            : f
        )
      );

      const item = files.find((f) => f.id === fileId);
      if (!item) return;

      const startTime = performance.now();

      try {
        if (item.type === 'image') {
          const result = await compressImage(item.file, currentOpts, (progress) => {
            setFiles((prev) =>
              prev.map((f) => (f.id === fileId ? { ...f, progress } : f))
            );
          });

          const endTime = performance.now();

          setFiles((prev) =>
            prev.map((f) =>
              f.id === fileId
                ? {
                    ...f,
                    status: 'completed',
                    progress: 100,
                    compressedBlob: result.blob,
                    compressedSize: result.size,
                    compressedPreviewUrl: result.previewUrl,
                    processingTimeMs: Math.round(endTime - startTime),
                    width: result.width,
                    height: result.height,
                  }
                : f
            )
          );
        } else {
          // PDF Compression
          const result = await compressPdf(item.file, currentOpts, (progress) => {
            setFiles((prev) =>
              prev.map((f) => (f.id === fileId ? { ...f, progress } : f))
            );
          });

          const endTime = performance.now();

          setFiles((prev) =>
            prev.map((f) =>
              f.id === fileId
                ? {
                    ...f,
                    status: 'completed',
                    progress: 100,
                    compressedBlob: result.blob,
                    compressedSize: result.size,
                    compressedPreviewUrl: result.previewUrl,
                    pageCount: result.pageCount,
                    processingTimeMs: Math.round(endTime - startTime),
                  }
                : f
            )
          );
        }
      } catch (err: any) {
        console.error('Compression error:', err);
        setFiles((prev) =>
          prev.map((f) =>
            f.id === fileId
              ? {
                  ...f,
                  status: 'error',
                  progress: 0,
                  errorMessage: err?.message || 'Compression failed',
                }
              : f
          )
        );
      }
    },
    [files, options]
  );

  // Compress all pending or error files in queue
  const handleCompressAll = async () => {
    setIsCompressingAll(true);
    for (const f of files) {
      if (f.status !== 'completed') {
        await compressSingleFile(f.id);
      }
    }
    setIsCompressingAll(false);
  };

  // Remove single file
  const handleRemoveFile = (fileId: string) => {
    setFiles((prev) => {
      const item = prev.find((f) => f.id === fileId);
      if (item?.originalPreviewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(item.originalPreviewUrl);
      }
      if (item?.compressedPreviewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(item.compressedPreviewUrl);
      }
      return prev.filter((f) => f.id !== fileId);
    });
  };

  // Clear all files
  const handleClearAll = () => {
    files.forEach((f) => {
      if (f.originalPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(f.originalPreviewUrl);
      if (f.compressedPreviewUrl?.startsWith('blob:')) URL.revokeObjectURL(f.compressedPreviewUrl);
    });
    setFiles([]);
  };

  // Quick preset selected from guideline badge
  const handleSelectGuidelineSize = (size: number, unit: TargetUnit) => {
    setOptions((prev) => ({
      ...prev,
      mode: 'target_size',
      targetSizeValue: size,
      targetSizeUnit: unit,
    }));
  };

  return (
    <div className="min-h-screen bg-stone-100/70 dark:bg-stone-950 text-stone-800 dark:text-stone-100 font-sans transition-colors pb-16">
      {/* Header */}
      <Header
        t={t}
        lang={lang}
        setLang={setLang}
        isDark={isDark}
        setIsDark={setIsDark}
      />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Hero Banner / Highlight */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold bg-orange-100/80 dark:bg-orange-950/60 text-orange-800 dark:text-orange-300 px-3 py-1 rounded-full border border-orange-200/80 dark:border-orange-800/80">
            <Zap className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
            <span>
              {lang === 'hi'
                ? 'कस्टम KB / MB लिखें और तुरंत कंप्रेस करें'
                : 'Exact Target Size Optimizer for PDF & Photos'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 dark:text-white tracking-tight">
            {t.title}
          </h2>
          <p className="text-sm text-stone-600 dark:text-stone-400 leading-relaxed">
            {t.subtitle}
          </p>
        </div>

        {/* Target Size Control (Core Requirement: Write custom KB / MB) */}
        <TargetSizeControl
          t={t}
          lang={lang}
          options={options}
          setOptions={setOptions}
          filesCount={files.length}
        />

        {/* Govt Form Guidelines Cards */}
        <GovtGuidelineBadge
          lang={lang}
          onSelectSize={handleSelectGuidelineSize}
        />

        {/* Upload DropZone */}
        <DropZone
          t={t}
          onFilesSelected={handleFilesSelected}
          hasFiles={files.length > 0}
        />

        {/* Batch Action Summary Bar (Sticky or Top of list when files exist) */}
        {files.length > 0 && (
          <BatchSummaryBar
            files={files}
            t={t}
            lang={lang}
            isCompressingAll={isCompressingAll}
            onCompressAll={handleCompressAll}
            onClearAll={handleClearAll}
          />
        )}

        {/* Files Queue List */}
        {files.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="font-bold text-sm text-stone-700 dark:text-stone-300 flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-orange-500" />
                <span>
                  {lang === 'hi' ? 'आपकी फाइल्स सूची' : 'Uploaded Files Queue'} (
                  {files.length})
                </span>
              </h3>
              <span className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'hi' ? 'टारगेट साइज' : 'Target'}:{' '}
                <strong>
                  {options.targetSizeValue} {options.targetSizeUnit}
                </strong>
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {files.map((item) => (
                <FileCard
                  key={item.id}
                  item={item}
                  t={t}
                  lang={lang}
                  onCompressSingle={compressSingleFile}
                  onRemove={handleRemoveFile}
                  onOpenPreview={setPreviewItem}
                  onOpenCompare={setCompareItem}
                />
              ))}
            </div>
          </div>
        )}

        {/* How It Works & Privacy Guarantees */}
        <div className="mt-12 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-bold text-stone-900 dark:text-white text-base">
              {lang === 'hi'
                ? 'सुरक्षा और प्राइवेसी गारंटी (100% Secure)'
                : '100% Private & In-Browser Processing'}
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-stone-600 dark:text-stone-400">
            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-100 dark:border-stone-800">
              <div className="font-semibold text-stone-800 dark:text-stone-200 mb-1">
                🔒 {lang === 'hi' ? 'जीरो सर्वर अपलोड' : 'Zero Server Uploads'}
              </div>
              <div>
                {lang === 'hi'
                  ? 'आपकी PDF और फोटो आपके फोन/कंप्यूटर के ब्राउज़र में ही प्रोसेस होती हैं।'
                  : 'All compression runs entirely in your local browser memory. Files never touch any server.'}
              </div>
            </div>
            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-100 dark:border-stone-800">
              <div className="font-semibold text-stone-800 dark:text-stone-200 mb-1">
                🎯 {lang === 'hi' ? 'सटीक KB / MB आउटपुट' : 'Exact Size Tuning'}
              </div>
              <div>
                {lang === 'hi'
                  ? 'बायनरी सर्च एल्गोरिद्म द्वारा तय किए गए साइज के अंदर सबसे बेहतरीन विजुअल क्वालिटी मिलती है।'
                  : 'Smart binary search algorithms calibrate quality and DPI to fit precisely within your target.'}
              </div>
            </div>
            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-100 dark:border-stone-800">
              <div className="font-semibold text-stone-800 dark:text-stone-200 mb-1">
                ⚡ {lang === 'hi' ? 'सुपरफास्ट स्पीड' : 'Lightning Fast'}
              </div>
              <div>
                {lang === 'hi'
                  ? 'बिना किसी वेटिंग या विज्ञापन के एक साथ कई फाइलों को सेकंडों में कंप्रेस करें।'
                  : 'Compress single or batch documents instantly with real-time before/after quality comparison.'}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Image Quality Comparison Modal */}
      <ImageComparisonModal
        item={compareItem}
        t={t}
        lang={lang}
        onClose={() => setCompareItem(null)}
      />

      {/* PDF Preview Modal */}
      <PdfPreviewModal
        item={previewItem}
        t={t}
        lang={lang}
        onClose={() => setPreviewItem(null)}
      />
    </div>
  );
}
